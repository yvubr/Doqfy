from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponse
from django.urls.base import reverse_lazy
# Create your views here.

"""landing base page starts from here """
def landing_base(request):
    if request.method == "GET":
        return render(request, 'home.html', {})
"""landing base page ends from here """