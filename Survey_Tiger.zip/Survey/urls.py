from django.urls import path
from Survey import views as Survey_views

app_name="Survey"

urlpatterns = [
     path('', Survey_views.landing_base, name="landingpage"),
    ]